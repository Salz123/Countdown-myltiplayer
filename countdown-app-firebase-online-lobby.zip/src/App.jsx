import React, { useEffect, useRef, useState } from "react";
import { db } from "./firebase";
import { ref, set, update, onValue, get, child } from "firebase/database";

/**
 * Countdown (Classical + Freeplay) - styled to match provided screenshots.
 * Classical = 9 rounds:
 * Letters, Letters, Numbers, Letters, Letters, Numbers, Letters, Letters, Conundrum
 */

const ROUND_SEQUENCE = [
  "LETTERS",
  "LETTERS",
  "NUMBERS",
  "LETTERS",
  "LETTERS",
  "NUMBERS",
  "LETTERS",
  "LETTERS",
  "CONUNDRUM",
];

const DEFAULT_SECONDS = 30;

function repeat(ch, n) {
  return Array.from({ length: n }, () => ch);
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

/** -------------------- LETTER BAG -------------------- **/

const LETTER_BAG = {
  vowels: [
    ...repeat("A", 9),
    ...repeat("E", 12),
    ...repeat("I", 9),
    ...repeat("O", 8),
    ...repeat("U", 4),
  ],
  consonants: [
    ...repeat("B", 2),
    ...repeat("C", 2),
    ...repeat("D", 4),
    ...repeat("F", 2),
    ...repeat("G", 3),
    ...repeat("H", 2),
    ...repeat("J", 1),
    ...repeat("K", 1),
    ...repeat("L", 4),
    ...repeat("M", 2),
    ...repeat("N", 6),
    ...repeat("P", 2),
    ...repeat("Q", 1),
    ...repeat("R", 6),
    ...repeat("S", 4),
    ...repeat("T", 6),
    ...repeat("V", 2),
    ...repeat("W", 2),
    ...repeat("X", 1),
    ...repeat("Y", 2),
    ...repeat("Z", 1),
  ],
};

/** -------------------- SCORING -------------------- **/

function scoreLetters(word) {
  const w = (word || "").trim();
  return w.length;
}

function scoreNumbers(target, value) {
  const diff = Math.abs(target - value);
  if (diff === 0) return 10;
  if (diff <= 5) return 7;
  if (diff <= 10) return 5;
  return 0;
}

function scoreConundrum(isCorrect) {
  return isCorrect ? 10 : 0;
}

/** -------------------- SAFE EVAL (Numbers) -------------------- **/

function safeEval(expr) {
  const s = (expr || "").trim();
  if (!s) return null;
  if (!/^[0-9+\-*/().\s]+$/.test(s)) return null;
  try {
    // eslint-disable-next-line no-new-func
    const fn = new Function(`"use strict"; return (${s});`);
    const val = fn();
    if (typeof val !== "number" || !Number.isFinite(val)) return null;
    return val;
  } catch {
    return null;
  }
}

/** -------------------- STRICT VALIDATION -------------------- **/

function isValidWord(word, wordSet) {
  const w = (word || "").trim().toUpperCase();
  if (!w) return false;
  if (!/^[A-Z]+$/.test(w)) return false;
  if (!wordSet) return false;
  return wordSet.has(w);
}

function canFormWordFromLetters(word, letters) {
  const w = (word || "").trim().toUpperCase();
  if (!w) return false;
  const counts = new Map();
  for (const ch of letters) counts.set(ch, (counts.get(ch) || 0) + 1);
  for (const ch of w) {
    const c = counts.get(ch) || 0;
    if (c <= 0) return false;
    counts.set(ch, c - 1);
  }
  return true;
}

function expressionUsesOnlyGivenNumbers(expr, allowedNumbers) {
  const s = (expr || "").trim();
  if (!s) return false;

  const nums = s.match(/\d+/g) || [];
  if (nums.length === 0) return false;

  const counts = new Map();
  for (const n of allowedNumbers) {
    const k = String(n);
    counts.set(k, (counts.get(k) || 0) + 1);
  }

  for (const tok of nums) {
    const c = counts.get(tok) || 0;
    if (c <= 0) return false;
    counts.set(tok, c - 1);
  }
  return true;
}

/** -------------------- ONLINE WORDLIST (NO API) + CACHING -------------------- **/

const WORDLIST_URLS = [
  "https://raw.githubusercontent.com/dwyl/english-words/master/words_alpha.txt",
  "https://cdn.jsdelivr.net/gh/dwyl/english-words@master/words_alpha.txt",
  "https://raw.fastgit.org/dwyl/english-words/master/words_alpha.txt",
];

const DB_NAME = "countdown_dictionary_db_v1";
const DB_VERSION = 1;
const STORE_MAIN = "main";
const STORE_META = "meta";
const KEY_WORDLIST_TEXT = "wordlist_text";
const KEY_WORDLIST_META = "wordlist_meta";
const KEY_NINE_INDEX = "nine_letter_index";

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_MAIN)) db.createObjectStore(STORE_MAIN);
      if (!db.objectStoreNames.contains(STORE_META)) db.createObjectStore(STORE_META);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function idbGet(db, store, key) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, "readonly");
    const st = tx.objectStore(store);
    const req = st.get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function idbPut(db, store, key, value) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, "readwrite");
    const st = tx.objectStore(store);
    const req = st.put(value, key);
    req.onsuccess = () => resolve(true);
    req.onerror = () => reject(req.error);
  });
}

async function fetchWordlistTextWithFallback() {
  let lastErr = null;
  for (const url of WORDLIST_URLS) {
    try {
      const res = await fetch(url, { cache: "force-cache" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      if (text && text.length > 500000) {
        return { text, url };
      }
      throw new Error("Wordlist too small or empty");
    } catch (e) {
      lastErr = e;
    }
  }
  throw new Error(`Failed to fetch wordlist from all mirrors: ${String(lastErr?.message || lastErr)}`);
}

function textToWordSet(text) {
  const set = new Set();
  const lines = text.split(/\r?\n/);
  for (const line of lines) {
    const w = (line || "").trim();
    if (!w) continue;
    if (!/^[a-z]+$/i.test(w)) continue;
    set.add(w.toUpperCase());
  }
  return set;
}

function buildNineLetterIndex(wordSet, max = 40000) {
  const nine = [];
  for (const w of wordSet) {
    if (w.length === 9) {
      nine.push(w);
      if (nine.length >= max) break;
    }
  }
  return nine;
}

async function loadDictionaryAssets(onStatus) {
  let db = null;
  try {
    db = await openDB();
  } catch {
    // IndexedDB blocked/unavailable
  }

  if (db) {
    try {
      const cachedText = await idbGet(db, STORE_MAIN, KEY_WORDLIST_TEXT);
      const cachedNine = await idbGet(db, STORE_MAIN, KEY_NINE_INDEX);
      const cachedMeta = await idbGet(db, STORE_META, KEY_WORDLIST_META);

      if (cachedText && typeof cachedText === "string" && cachedText.length > 500000) {
        onStatus?.("Loading dictionary from cache…");
        const wordSet = textToWordSet(cachedText);

        if (Array.isArray(cachedNine) && cachedNine.length > 1000) {
          return { wordSet, nineIndex: cachedNine, meta: cachedMeta || null };
        }

        onStatus?.("Building 9-letter index…");
        const nineIndex = buildNineLetterIndex(wordSet);
        try {
          await idbPut(db, STORE_MAIN, KEY_NINE_INDEX, nineIndex);
        } catch {}
        return { wordSet, nineIndex, meta: cachedMeta || null };
      }
    } catch {}
  }

  onStatus?.("Downloading dictionary…");
  const { text, url } = await fetchWordlistTextWithFallback();
  onStatus?.("Indexing dictionary…");
  const wordSet = textToWordSet(text);

  onStatus?.("Building 9-letter index…");
  const nineIndex = buildNineLetterIndex(wordSet);

  const meta = { sourceUrl: url, savedAt: Date.now(), version: 1, count: wordSet.size, nineCount: nineIndex.length };

  if (db) {
    try {
      await idbPut(db, STORE_MAIN, KEY_WORDLIST_TEXT, text);
      await idbPut(db, STORE_MAIN, KEY_NINE_INDEX, nineIndex);
      await idbPut(db, STORE_META, KEY_WORDLIST_META, meta);
    } catch {}
  }

  return { wordSet, nineIndex, meta };
}

/** -------------------- UI -------------------- **/

function bgStyle() {
  return {
    minHeight: "100vh",
    background: "linear-gradient(180deg, #123C9A 0%, #2B56B8 40%, #2A4FB0 100%)",
    padding: "18px 14px 30px",
    color: "#fff",
    fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif",
  };
}

function Card({ children, style }) {
  return (
    <div
      style={{
        borderRadius: 18,
        background: "rgba(255,255,255,0.08)",
        border: "1px solid rgba(255,255,255,0.12)",
        boxShadow: "0 10px 30px rgba(0,0,0,0.18)",
        padding: 18,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

function Button({ children, onClick, variant = "ghost", disabled = false, style }) {
  const base = {
    width: "100%",
    borderRadius: 14,
    padding: "14px 14px",
    fontSize: 18,
    fontWeight: 700,
    border: "1px solid rgba(255,255,255,0.15)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.55 : 1,
    transition: "transform 120ms ease, opacity 120ms ease",
  };

  const v = {
    ghost: { background: "rgba(255,255,255,0.10)", color: "#fff" },
    green: { background: "#12A44A", color: "#fff", border: "1px solid rgba(0,0,0,0.12)" },
    red: { background: "#B7182A", color: "#fff", border: "1px solid rgba(0,0,0,0.12)" },
    blue: { background: "#1D57C9", color: "#fff", border: "1px solid rgba(0,0,0,0.12)" },
    purple: { background: "#7B2BE0", color: "#fff", border: "1px solid rgba(0,0,0,0.12)" },
    teal: { background: "#118F86", color: "#fff", border: "1px solid rgba(0,0,0,0.12)" },
  };

  return (
    <button
      onClick={disabled ? undefined : onClick}
      style={{ ...base, ...v[variant], ...style }}
      onMouseDown={(e) => {
        if (disabled) return;
        e.currentTarget.style.transform = "scale(0.99)";
      }}
      onMouseUp={(e) => {
        e.currentTarget.style.transform = "scale(1)";
      }}
    >
      {children}
    </button>
  );
}

function SmallButton({ children, onClick, disabled = false, style }) {
  return (
    <button
      onClick={disabled ? undefined : onClick}
      style={{
        borderRadius: 12,
        padding: "10px 12px",
        background: "rgba(255,255,255,0.10)",
        border: "1px solid rgba(255,255,255,0.15)",
        color: "#fff",
        fontWeight: 700,
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.55 : 1,
        ...style,
      }}
    >
      {children}
    </button>
  );
}

function Tile({ text, size = 64, style }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: 14,
        background: "#F2C500",
        color: "#173A87",
        fontWeight: 900,
        fontSize: 26,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        boxShadow: "0 8px 0 rgba(0,0,0,0.12)",
        ...style,
      }}
    >
      {text}
    </div>
  );
}

function EmptyTile({ size = 64 }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: 14,
        border: "2px dashed rgba(255,255,255,0.25)",
        background: "rgba(255,255,255,0.05)",
      }}
    />
  );
}

function NumberTile({ text, size = 64 }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: 14,
        background: "#1C66D6",
        color: "#fff",
        fontWeight: 900,
        fontSize: 22,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        boxShadow: "0 8px 0 rgba(0,0,0,0.10)",
      }}
    >
      {text}
    </div>
  );
}

function TextInput({ value, onChange, placeholder, disabled = false }) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      disabled={disabled}
      style={{
        width: "100%",
        borderRadius: 12,
        padding: "14px 14px",
        fontSize: 16,
        border: "1px solid rgba(255,255,255,0.20)",
        background: "rgba(255,255,255,0.12)",
        color: "#fff",
        outline: "none",
      }}
    />
  );
}

function ProgressSegments({ total, done }) {
  return (
    <div style={{ display: "flex", gap: 6, marginTop: 10 }}>
      {Array.from({ length: total }).map((_, i) => {
        const isDone = i < done;
        const isCurrent = i === done;
        let bg = "rgba(255,255,255,0.18)";
        if (isDone) bg = "#21B14B";
        if (isCurrent) bg = "#F2C500";
        return (
          <div
            key={i}
            style={{
              flex: 1,
              height: 10,
              borderRadius: 10,
              background: bg,
            }}
          />
        );
      })}
    </div>
  );
}

function TimerBar({ totalSeconds, secondsLeft, running }) {
  const pct = totalSeconds <= 0 ? 0 : (secondsLeft / totalSeconds) * 100;
  return (
    <div style={{ marginTop: 14 }}>
      <div
        style={{
          height: 16,
          borderRadius: 14,
          background: "rgba(255,255,255,0.14)",
          border: "1px solid rgba(255,255,255,0.18)",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            height: "100%",
            width: `${clamp(pct, 0, 100)}%`,
            background: running ? "#12A44A" : "rgba(18,164,74,0.65)",
            borderRadius: 14,
            transition: running ? "width 200ms linear" : "none",
          }}
        />
      </div>
      <div style={{ textAlign: "center", marginTop: 10, fontSize: 28, fontWeight: 800 }}>
        {secondsLeft}s
      </div>
    </div>
  );
}

/** -------------------- APP -------------------- **/

export default function App() {
  const [route, setRoute] = useState("MODE");
  const [online, setOnline] = useState({ mode: null, code: '', status: 'idle', error: null, room: null, playerId: null, name: 'Player' });
 // MODE | CLASSICAL_INFO | CLASSICAL_GAME | FREEPLAY
  const [classicState, setClassicState] = useState(() => makeNewClassicalState());
  const [freeplayState, setFreeplayState] = useState(() => makeNewFreeplayState());

  const [wordSet, setWordSet] = useState(null);
  const [nineIndex, setNineIndex] = useState(null);
  const [dictStatus, setDictStatus] = useState("Preparing…");
  const [dictError, setDictError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const assets = await loadDictionaryAssets((s) => {
          if (!cancelled) setDictStatus(s);
        });
        if (!cancelled) {
          setWordSet(assets.wordSet);
          setNineIndex(assets.nineIndex);
          setDictStatus(`Dictionary ready (${assets.wordSet.size.toLocaleString()} words)`);
        }
      } catch (e) {
        if (!cancelled) {
          setDictError(String(e?.message || e));
          setDictStatus("Dictionary unavailable");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  function resetToMode() {
    setRoute("MODE");
  }

// -------------------- ONLINE (Firebase RTDB) --------------------
function ensurePlayerId() {
  try {
    const key = "countdown_player_id";
    let id = localStorage.getItem(key);
    if (!id) {
      id = (crypto?.randomUUID?.() || String(Math.random()).slice(2)) + "_" + Date.now();
      localStorage.setItem(key, id);
    }
    return id;
  } catch {
    return "p_" + String(Math.random()).slice(2) + "_" + Date.now();
  }
}

function genRoomCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

async function createOnlineRoom() {
  const playerId = ensurePlayerId();
  const code = genRoomCode();
  setOnline((o) => ({ ...o, status: "creating", error: null, code, playerId }));
  const roomRef = ref(db, "rooms/" + code);
  const name = online.name?.trim() || "Player 1";
  const room = {
    code,
    phase: "lobby",
    hostId: playerId,
    createdAt: Date.now(),
    players: {
      [playerId]: { name, score: 0, connected: true, joinedAt: Date.now() },
    },
  };
  try {
    await set(roomRef, room);
    subscribeRoom(code);
    setRoute("ONLINE_LOBBY");
    window.scrollTo?.(0, 0);
  } catch (e) {
    setOnline((o) => ({ ...o, status: "error", error: String(e) }));
  }
}

async function joinOnlineRoom(codeRaw) {
  const code = (codeRaw || "").trim().toUpperCase();
  if (!code) return;
  const playerId = ensurePlayerId();
  setOnline((o) => ({ ...o, status: "joining", error: null, code, playerId }));
  try {
    const roomSnap = await get(ref(db, "rooms/" + code));
    if (!roomSnap.exists()) {
      setOnline((o) => ({ ...o, status: "error", error: "Room not found." }));
      return;
    }
    const name = online.name?.trim() || "Player";
    await update(ref(db, "rooms/" + code + "/players/" + playerId), {
      name,
      score: 0,
      connected: true,
      joinedAt: Date.now(),
    });
    subscribeRoom(code);
    setRoute("ONLINE_LOBBY");
    window.scrollTo?.(0, 0);
  } catch (e) {
    setOnline((o) => ({ ...o, status: "error", error: String(e) }));
  }
}

function subscribeRoom(code) {
  const roomRef = ref(db, "rooms/" + code);
  onValue(
    roomRef,
    (snap) => {
      const room = snap.val();
      setOnline((o) => ({ ...o, status: "ready", room, error: null }));
    },
    (err) => {
      setOnline((o) => ({ ...o, status: "error", error: String(err) }));
    }
  );
}

async function updateMyName(name) {
  const code = online.code;
  const playerId = online.playerId;
  setOnline((o) => ({ ...o, name }));
  if (!code || !playerId) return;
  try {
    await update(ref(db, "rooms/" + code + "/players/" + playerId), { name });
  } catch {
    // ignore
  }
}


  function startClassical() {
    setClassicState(makeNewClassicalState());
    setRoute("CLASSICAL_GAME");
  }

  function goClassicalInfo() {
    setRoute("CLASSICAL_INFO");
  }

  function goFreeplay() {
    setFreeplayState(makeNewFreeplayState());
    setRoute("FREEPLAY");
  }

  return (
    <div style={bgStyle()}>
      <Header />

      <div style={{ maxWidth: 520, margin: "0 auto 14px", opacity: 0.85, fontWeight: 700, textAlign: "center" }}>
        {dictError ? `Dictionary error: ${dictError}` : dictStatus}
      </div>

      {route === "MODE" && <ModeSelection onClassical={goClassicalInfo} onFreeplay={goFreeplay} />}

      {route === "CLASSICAL_INFO" && <ClassicalInfo onBack={resetToMode} onStart={startClassical} />}

      {route === "CLASSICAL_GAME" && (
        <ClassicalGame
          state={classicState}
          setState={setClassicState}
          onBackToMode={resetToMode}
          wordSet={wordSet}
          nineIndex={nineIndex}
        />
      )}

      

{route === "ONLINE_MENU" && (
  <OnlineMenu
    name={online.name}
    onNameChange={updateMyName}
    status={online.status}
    error={online.error}
    onCreate={createOnlineRoom}
    onJoin={(code) => joinOnlineRoom(code)}
    onBack={() => setRoute("CLASSICAL_INFO")}
  />
)}

{route === "ONLINE_LOBBY" && (
  <OnlineLobby
    online={online}
    onBack={() => setRoute("ONLINE_MENU")}
  />
)}
{route === "FREEPLAY" && (
        <Freeplay
          state={freeplayState}
          setState={setFreeplayState}
          onBackToMode={resetToMode}
          wordSet={wordSet}
          nineIndex={nineIndex}
        />
      )}
    </div>
  );
}

function Header() {
  return (
    <div style={{ textAlign: "center", marginTop: 6, marginBottom: 18 }}>
      <div style={{ fontSize: 58, fontWeight: 900, letterSpacing: 2 }}>COUNTDOWN</div>
      <div style={{ marginTop: 6, opacity: 0.9, fontSize: 18 }}>Test your word and number skills</div>
    </div>
  );
}

/** -------------------- MODE SELECTION -------------------- **/

function ModeSelection({ onClassical, onFreeplay }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16, maxWidth: 520, margin: "0 auto" }}>
      <div style={{ textAlign: "center", fontSize: 28, fontWeight: 800, marginBottom: 6 }}>Choose Your Mode</div>

      <Card style={{ padding: 22 }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
          <div style={{ fontSize: 42 }}>👥</div>
          <div style={{ fontSize: 32, fontWeight: 900 }}>Classical Mode</div>
          <div style={{ opacity: 0.9, textAlign: "center" }}>
            Play through 9 rounds in traditional TV show format
          </div>
          <div style={{ width: "100%", marginTop: 6, opacity: 0.85, lineHeight: 1.8 }}>
            <div>• 6 Letters Rounds</div>
            <div>• 2 Numbers Rounds</div>
            <div>• 1 Conundrum Finale</div>
            <div>• Best for 2+ players</div>
          </div>

          <div style={{ width: "100%", marginTop: 14 }}>
            <Button variant="ghost" onClick={onClassical}>
              Open Classical Mode
            </Button>
          </div>
        </div>
      </Card>

      <Card style={{ padding: 22 }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
          <div style={{ fontSize: 42 }}>🎮</div>
          <div style={{ fontSize: 32, fontWeight: 900 }}>Free Mode</div>
          <div style={{ opacity: 0.9, textAlign: "center" }}>Practice any round at your own pace</div>
          <div style={{ width: "100%", marginTop: 6, opacity: 0.85, lineHeight: 1.8 }}>
            <div>• Choose any round type</div>
            <div>• Play as many times as you want</div>
            <div>• Track cumulative score</div>
            <div>• Perfect for practice</div>
          </div>

          <div style={{ width: "100%", marginTop: 14 }}>
            <Button variant="ghost" onClick={onFreeplay}>
              Open Free Mode
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}

/** -------------------- CLASSICAL INFO -------------------- **/

function ClassicalInfo({ onBack, onStart }) {
  return (
    <div style={{ maxWidth: 520, margin: "0 auto", display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ marginBottom: 6 }}>
        <SmallButton onClick={onBack} style={{ width: "100%" }}>
          ← Back to Mode Selection
        </SmallButton>
      </div>

      <Card>
        <div style={{ textAlign: "center", fontSize: 40, fontWeight: 900, lineHeight: 1.1 }}>
          Classical
          <br />
          Countdown
        </div>
        <div style={{ textAlign: "center", marginTop: 10, opacity: 0.9, fontWeight: 800 }}>Game Format</div>

        <Card style={{ marginTop: 14 }}>
          <div style={{ opacity: 0.9, lineHeight: 1.8 }}>
            <div>
              This is the traditional Countdown format with <b>9 rounds</b>:
            </div>
            <div style={{ marginTop: 10 }}>
              • Rounds 1, 2, 4, 5, 7, 8: Letters (both players compete)
            </div>
            <div>• Rounds 3, 6: Numbers (both players compete)</div>
            <div>• Round 9: Conundrum (both players compete)</div>
            <div>• Best answer wins the points for that round</div>
            <div>• Same answer = both players get points</div>
          </div>
        </Card>

        <div style={{ textAlign: "center", marginTop: 16, fontSize: 28, fontWeight: 900 }}>Scoring</div>

        <Card style={{ marginTop: 10 }}>
          <div style={{ opacity: 0.92, lineHeight: 1.9 }}>
            <div>
              <span style={{ color: "#F2C500", fontWeight: 900 }}>• Letters:</span> 1 point per letter in valid word
            </div>
            <div>
              <span style={{ color: "#F2C500", fontWeight: 900 }}>• Numbers:</span> 10 points exact, 7 within 5, 5
              within 10
            </div>
            <div>
              <span style={{ color: "#F2C500", fontWeight: 900 }}>• Conundrum:</span> 10 points for correct answer
            </div>
          </div>
        </Card>

        <div style={{ marginTop: 18 }}>
          <Button variant="green" onClick={onStart}>
            Start Game
          </Button>
        </div>
      </Card>
    </div>
  );
}

/** -------------------- CLASSICAL GAME -------------------- **/

function makeNewClassicalState() {
  return {
    roundIndex: 0,
    scores: { p1: 0, p2: 0 },
    breakdown: { letters: 0, numbers: 0, conundrum: 0 },
    currentRound: null,
  };
}

function ClassicalGame({ state, setState, onBackToMode, wordSet, nineIndex }) {
  const roundType = ROUND_SEQUENCE[state.roundIndex];
  const roundLabel =
    roundType === "LETTERS"
      ? `Letters Round ${lettersOrdinal(state.roundIndex)}`
      : roundType === "NUMBERS"
      ? `Numbers Round ${numbersOrdinal(state.roundIndex)}`
      : "Conundrum";

  useEffect(() => {
    if (!state.currentRound) {
      setState((s) => ({ ...s, currentRound: makeRoundState(roundType, wordSet, nineIndex) }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.roundIndex]);

  function goNextRound() {
    setState((s) => {
      const next = s.roundIndex + 1;
      if (next >= ROUND_SEQUENCE.length) return s;
      return { ...s, roundIndex: next, currentRound: null };
    });
  }

  function awardPoints(p1Add, p2Add, bucket, contributionForBreakdown) {
    setState((s) => ({
      ...s,
      scores: { p1: s.scores.p1 + p1Add, p2: s.scores.p2 + p2Add },
      breakdown: {
        ...s.breakdown,
        [bucket]: s.breakdown[bucket] + (contributionForBreakdown || 0),
      },
    }));
  }

  const finishedAll = state.roundIndex >= ROUND_SEQUENCE.length - 1 && state.currentRound?.phase === "DONE";

  return (
    <div style={{ maxWidth: 520, margin: "0 auto", display: "flex", flexDirection: "column", gap: 14 }}>
      <SmallButton onClick={onBackToMode} style={{ width: "100%" }}>
        ← Back to Mode Selection
      </SmallButton>

      <RoundStatusCard
        roundIndex={state.roundIndex}
        roundLabel={roundLabel}
        scores={state.scores}
        doneSegments={state.roundIndex}
        totalSegments={ROUND_SEQUENCE.length}
      />

      {finishedAll ? (
        <FinalScoreCard
          scores={state.scores}
          breakdown={state.breakdown}
          onRestart={() => setState(makeNewClassicalState())}
          onBack={onBackToMode}
        />
      ) : (
        <RoundRenderer
          type={roundType}
          round={state.currentRound}
          setRound={(updater) => {
            setState((s) => ({
              ...s,
              currentRound: typeof updater === "function" ? updater(s.currentRound) : updater,
            }));
          }}
          wordSet={wordSet}
          nineIndex={nineIndex}
          onAward={(p1Add, p2Add, bucket, contribution) => awardPoints(p1Add, p2Add, bucket, contribution)}
          onNext={goNextRound}
        />
      )}
    </div>
  );
}

function lettersOrdinal(roundIndex) {
  return ROUND_SEQUENCE.slice(0, roundIndex + 1).filter((t) => t === "LETTERS").length;
}

function numbersOrdinal(roundIndex) {
  return ROUND_SEQUENCE.slice(0, roundIndex + 1).filter((t) => t === "NUMBERS").length;
}

function RoundStatusCard({ roundIndex, roundLabel, scores, doneSegments, totalSegments }) {
  return (
    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
        <div>
          <div style={{ fontSize: 26, fontWeight: 900 }}>
            Round {roundIndex + 1} of {ROUND_SEQUENCE.length}
          </div>
          <div style={{ opacity: 0.9, marginTop: 4 }}>{roundLabel}</div>
          <div style={{ color: "#F2C500", fontWeight: 900, marginTop: 4 }}>Both players compete</div>
        </div>
        <div style={{ textAlign: "right", fontWeight: 900 }}>
          <div>Player 1: {scores.p1}</div>
          <div style={{ marginTop: 6 }}>Player 2: {scores.p2}</div>
        </div>
      </div>
      <ProgressSegments total={totalSegments} done={doneSegments} />
    </Card>
  );
}

function FinalScoreCard({ scores, breakdown, onRestart, onBack }) {
  return (
    <Card>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ fontSize: 30 }}>🏆</div>
        <div style={{ fontSize: 24, fontWeight: 900 }}>Total Score</div>
      </div>

      <div style={{ marginTop: 12, display: "flex", justifyContent: "space-between", fontWeight: 900 }}>
        <div>Player 1: {scores.p1}</div>
        <div>Player 2: {scores.p2}</div>
      </div>

      <Card style={{ marginTop: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", opacity: 0.9 }}>
          <div>Letters:</div>
          <div>{breakdown.letters}</div>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", opacity: 0.9, marginTop: 8 }}>
          <div>Numbers:</div>
          <div>{breakdown.numbers}</div>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", opacity: 0.9, marginTop: 8 }}>
          <div>Conundrum:</div>
          <div>{breakdown.conundrum}</div>
        </div>
      </Card>

      <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
        <Button variant="ghost" onClick={onBack} style={{ width: "50%" }}>
          ← Back to Menu
        </Button>
        <Button variant="green" onClick={onRestart} style={{ width: "50%" }}>
          Restart
        </Button>
      </div>
    </Card>
  );
}

/** -------------------- ROUND FACTORY -------------------- **/

function makeRoundState(type, wordSet, nineIndex) {
  if (type === "LETTERS") return makeLettersRound();
  if (type === "NUMBERS") return makeNumbersRound();
  return makeConundrumRound(wordSet, nineIndex);
}

function RoundRenderer({ type, round, setRound, onAward, onNext, wordSet, nineIndex }) {
  if (!round) return null;
  if (type === "LETTERS") {
    return <LettersRound round={round} setRound={setRound} onAward={onAward} onNext={onNext} wordSet={wordSet} />;
  }
  if (type === "NUMBERS") {
    return <NumbersRound round={round} setRound={setRound} onAward={onAward} onNext={onNext} />;
  }
  return (
    <ConundrumRound
      round={round}
      setRound={setRound}
      onAward={onAward}
      onNext={onNext}
      wordSet={wordSet}
      nineIndex={nineIndex}
    />
  );
}

/** -------------------- LETTERS ROUND -------------------- **/

function makeLettersRound() {
  return {
    phase: "PICKING", // PICKING | READY | RUNNING | DONE
    letters: [],
    secondsLeft: DEFAULT_SECONDS,
    p1: "",
    p2: "",
    results: null,
  };
}

function LettersRound({ round, setRound, onAward, onNext, wordSet }) {
  const running = round.phase === "RUNNING";
  const ready = round.phase === "READY";
  const done = round.phase === "DONE";

  useCountdownTimer(round, setRound);

  function addLetter(kind) {
    setRound((r) => {
      if (r.phase !== "PICKING") return r;
      if (r.letters.length >= 9) return { ...r, phase: "READY" };
      const bag = kind === "VOWEL" ? LETTER_BAG.vowels : LETTER_BAG.consonants;
      const next = pickRandom(bag);
      const letters = [...r.letters, next];
      const phase = letters.length >= 9 ? "READY" : "PICKING";
      return { ...r, letters, phase };
    });
  }

  function startTimer() {
    setRound((r) => {
      if (r.phase !== "READY") return r;
      return { ...r, phase: "RUNNING", secondsLeft: DEFAULT_SECONDS };
    });
  }

  function finishRound() {
    const w1 = (round.p1 || "").trim().toUpperCase();
    const w2 = (round.p2 || "").trim().toUpperCase();

    const v1 = isValidWord(w1, wordSet) && canFormWordFromLetters(w1, round.letters);
    const v2 = isValidWord(w2, wordSet) && canFormWordFromLetters(w2, round.letters);

    const s1 = v1 ? scoreLetters(w1) : 0;
    const s2 = v2 ? scoreLetters(w2) : 0;

    let p1Add = 0;
    let p2Add = 0;
    let winner = 0;

    if (w1 && w2 && w1 === w2 && v1 && v2) {
      p1Add = s1;
      p2Add = s2;
      winner = 0;
    } else if (s1 > s2) {
      p1Add = s1;
      winner = 1;
    } else if (s2 > s1) {
      p2Add = s2;
      winner = 2;
    } else {
      if (s1 > 0 && s2 > 0 && s1 === s2) {
        p1Add = s1;
        p2Add = s2;
        winner = 0;
      }
    }

    onAward(p1Add, p2Add, "letters", Math.max(p1Add, p2Add));

    setRound((r) => ({
      ...r,
      phase: "DONE",
      results: {
        p1: { word: w1, valid: v1, points: p1Add, base: s1 },
        p2: { word: w2, valid: v2, points: p2Add, base: s2 },
        winner,
      },
    }));
  }

  useEffect(() => {
    if (round.phase === "RUNNING" && round.secondsLeft <= 0) {
      setRound((r) => ({ ...r, phase: "DONE" }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [round.secondsLeft, round.phase]);

  useEffect(() => {
    if (round.phase === "DONE" && !round.results) finishRound();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [round.phase]);

  return (
    <Card>
      <div style={{ textAlign: "center", fontSize: 40, fontWeight: 900 }}>Letters Round</div>

      {!wordSet && (
        <div style={{ textAlign: "center", marginTop: 8, opacity: 0.9, fontWeight: 800 }}>
          Loading dictionary…
        </div>
      )}

      <div style={{ textAlign: "center", marginTop: 10, opacity: 0.9 }}>
        {round.phase === "PICKING"
          ? `Select 9 letters (${9 - round.letters.length} remaining)`
          : `Select 9 letters (0 remaining)`}
      </div>

      <div style={{ display: "flex", gap: 12, marginTop: 14 }}>
        <Button
          variant="red"
          onClick={() => addLetter("CONSONANT")}
          disabled={round.phase !== "PICKING"}
          style={{ width: "50%" }}
        >
          Consonant
        </Button>
        <Button
          variant="blue"
          onClick={() => addLetter("VOWEL")}
          disabled={round.phase !== "PICKING"}
          style={{ width: "50%" }}
        >
          Vowel
        </Button>
      </div>

      <div style={{ marginTop: 16, display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
        <div style={{ display: "flex", gap: 12 }}>
          {Array.from({ length: 4 }).map((_, i) =>
            round.letters[i] ? <Tile key={i} text={round.letters[i]} /> : <EmptyTile key={i} />
          )}
        </div>
        <div style={{ display: "flex", gap: 12 }}>
          {Array.from({ length: 4 }).map((_, i) => {
            const idx = 4 + i;
            return round.letters[idx] ? <Tile key={idx} text={round.letters[idx]} /> : <EmptyTile key={idx} />;
          })}
        </div>
        <div>{round.letters[8] ? <Tile text={round.letters[8]} /> : <EmptyTile />}</div>
      </div>

      <div style={{ marginTop: 18 }}>
        <Button variant="green" onClick={startTimer} disabled={!ready || !wordSet}>
          Start Timer
        </Button>
      </div>

      {(running || done) && <TimerBar totalSeconds={DEFAULT_SECONDS} secondsLeft={round.secondsLeft} running={running} />}

      <div style={{ marginTop: 14 }}>
        <div style={{ fontWeight: 900, marginBottom: 8 }}>Player 1&apos;s Word:</div>
        <TextInput
          value={round.p1}
          onChange={(v) => setRound((r) => ({ ...r, p1: v }))}
          placeholder="ENTER WORD..."
          disabled={!running && !done}
        />
      </div>

      <div style={{ marginTop: 14 }}>
        <div style={{ fontWeight: 900, marginBottom: 8 }}>Player 2&apos;s Word:</div>
        <TextInput
          value={round.p2}
          onChange={(v) => setRound((r) => ({ ...r, p2: v }))}
          placeholder="ENTER WORD..."
          disabled={!running && !done}
        />
      </div>

      {done && round.results && (
        <Card style={{ marginTop: 16 }}>
          <div style={{ textAlign: "center", fontWeight: 900, fontSize: 20, opacity: 0.95 }}>Time&apos;s Up!</div>

          <ResultRow
            label="Player 1"
            word={round.results.p1.word}
            valid={round.results.p1.valid}
            points={round.results.p1.points}
            base={round.results.p1.base}
            isWinner={round.results.winner === 1}
          />
          <ResultRow
            label="Player 2"
            word={round.results.p2.word}
            valid={round.results.p2.valid}
            points={round.results.p2.points}
            base={round.results.p2.base}
            isWinner={round.results.winner === 2}
          />

          <div style={{ marginTop: 12 }}>
            <Button variant="ghost" onClick={onNext}>
              Next Round
            </Button>
          </div>
        </Card>
      )}
    </Card>
  );
}

function ResultRow({ label, word, valid, points, base, isWinner }) {
  return (
    <div
      style={{
        marginTop: 12,
        borderRadius: 14,
        padding: 12,
        border: `1px solid ${isWinner ? "rgba(18,164,74,0.55)" : "rgba(255,255,255,0.14)"}`,
        background: isWinner ? "rgba(18,164,74,0.12)" : "rgba(255,255,255,0.05)",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 900 }}>
        <div>{label}</div>
        <div>{word || "-"}</div>
      </div>
      <div style={{ marginTop: 6, opacity: 0.9 }}>
        {valid ? "✓ Valid (uses selected letters)" : "✗ Invalid (not in dictionary or uses wrong letters)"} • {base} letters
        {isWinner && points > 0 ? <span style={{ marginLeft: 10 }}>🏆 Winner! +{points} points</span> : null}
        {!isWinner && points > 0 ? <span style={{ marginLeft: 10 }}>+{points} points</span> : null}
      </div>
    </div>
  );
}

/** -------------------- NUMBERS ROUND -------------------- **/

function makeNumbersRound() {
  return {
    phase: "PICKING", // PICKING | READY | RUNNING | DONE
    picksRemaining: 6,
    numbers: [],
    target: null,
    secondsLeft: DEFAULT_SECONDS,
    p1: "",
    p2: "",
    results: null,
  };
}

function NumbersRound({ round, setRound, onAward, onNext }) {
  const running = round.phase === "RUNNING";
  const ready = round.phase === "READY";
  const done = round.phase === "DONE";

  useCountdownTimer(round, setRound);

  function isLargeNumber(n) {
    return n === 25 || n === 50 || n === 75 || n === 100;
  }

  function pick(kind) {
    setRound((r) => {
      if (r.phase !== "PICKING") return r;
      if (r.picksRemaining <= 0) return r;

      const LARGE_SET = [25, 50, 75, 100];
      const largeChosen = r.numbers.filter(isLargeNumber).length;

      let num = null;

      if (kind === "LARGE") {
        // Max 4 large numbers, no duplicates, only 25/50/75/100
        if (largeChosen >= 4) return r;

        const availableLarge = LARGE_SET.filter((x) => !r.numbers.includes(x));
        if (availableLarge.length === 0) return r;

        num = pickRandom(availableLarge);
      } else {
        // Small numbers 1-10, duplicates allowed
        num = randInt(1, 10);
      }

      if (num == null) return r;

      const numbers = [...r.numbers, num];
      const picksRemaining = r.picksRemaining - 1;

      if (picksRemaining === 0) {
        const target = randInt(100, 999);
        return { ...r, numbers, picksRemaining, target, phase: "READY" };
      }
      return { ...r, numbers, picksRemaining };
    });
  }

  function startTimer() {
    setRound((r) => {
      if (r.phase !== "READY") return r;
      return { ...r, phase: "RUNNING", secondsLeft: DEFAULT_SECONDS };
    });
  }

  function finishRound() {
    const target = round.target ?? 0;

    const okUse1 = expressionUsesOnlyGivenNumbers(round.p1, round.numbers);
    const okUse2 = expressionUsesOnlyGivenNumbers(round.p2, round.numbers);

    const v1 = okUse1 ? safeEval(round.p1) : null;
    const v2 = okUse2 ? safeEval(round.p2) : null;

    const s1 = v1 == null ? 0 : scoreNumbers(target, v1);
    const s2 = v2 == null ? 0 : scoreNumbers(target, v2);

    let p1Add = 0;
    let p2Add = 0;
    let winner = 0;

    if (round.p1.trim() && round.p2.trim() && round.p1.trim() === round.p2.trim() && v1 != null && v2 != null) {
      p1Add = s1;
      p2Add = s2;
      winner = 0;
    } else if (s1 > s2) {
      p1Add = s1;
      winner = 1;
    } else if (s2 > s1) {
      p2Add = s2;
      winner = 2;
    } else {
      if (s1 > 0 && s2 > 0 && s1 === s2) {
        p1Add = s1;
        p2Add = s2;
        winner = 0;
      }
    }

    onAward(p1Add, p2Add, "numbers", Math.max(p1Add, p2Add));

    setRound((r) => ({
      ...r,
      phase: "DONE",
      results: {
        target,
        numbers: r.numbers,
        p1: { expr: r.p1, value: v1, points: p1Add, base: s1, usedOk: okUse1 },
        p2: { expr: r.p2, value: v2, points: p2Add, base: s2, usedOk: okUse2 },
        winner,
      },
    }));
  }

  useEffect(() => {
    if (round.phase === "RUNNING" && round.secondsLeft <= 0) {
      setRound((r) => ({ ...r, phase: "DONE" }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [round.secondsLeft, round.phase]);

  useEffect(() => {
    if (round.phase === "DONE" && !round.results && round.target != null) finishRound();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [round.phase]);

  const largeChosen = round.numbers.filter((n) => n === 25 || n === 50 || n === 75 || n === 100).length;

  return (
    <Card>
      <div style={{ textAlign: "center", fontSize: 40, fontWeight: 900 }}>Numbers Round</div>

      <div style={{ textAlign: "center", marginTop: 10, opacity: 0.9 }}>
        {round.phase === "PICKING"
          ? `Select 6 numbers (${round.picksRemaining} remaining)`
          : "Select 6 numbers (0 remaining)"}
      </div>

      <div style={{ display: "flex", gap: 12, marginTop: 14 }}>
        <Button
          variant="purple"
          onClick={() => pick("LARGE")}
          disabled={round.phase !== "PICKING" || largeChosen >= 4}
          style={{ width: "50%" }}
        >
          Large (25-100)
        </Button>
        <Button
          variant="teal"
          onClick={() => pick("SMALL")}
          disabled={round.phase !== "PICKING"}
          style={{ width: "50%" }}
        >
          Small (1-10)
        </Button>
      </div>

      {round.target != null && (
        <div style={{ marginTop: 18 }}>
          <div
            style={{
              borderRadius: 16,
              background: "#F2C500",
              padding: "18px 16px",
              color: "#173A87",
              textAlign: "center",
              fontWeight: 900,
            }}
          >
            <div style={{ fontSize: 16, opacity: 0.9 }}>Target Number</div>
            <div style={{ fontSize: 56, lineHeight: 1.0 }}>{round.target}</div>
          </div>

          <div style={{ textAlign: "center", marginTop: 14, fontWeight: 900, opacity: 0.95 }}>Your Numbers:</div>

          <div style={{ marginTop: 12, display: "flex", flexWrap: "wrap", gap: 12, justifyContent: "center" }}>
            {round.numbers.map((n, i) => (
              <NumberTile key={i} text={n} />
            ))}
          </div>

          <div style={{ marginTop: 18 }}>
            <Button variant="green" onClick={startTimer} disabled={!ready}>
              Start Timer
            </Button>
          </div>
        </div>
      )}

      {(running || done) && <TimerBar totalSeconds={DEFAULT_SECONDS} secondsLeft={round.secondsLeft} running={running} />}

      {round.target != null && (
        <>
          <div style={{ marginTop: 14 }}>
            <div style={{ fontWeight: 900, marginBottom: 8 }}>Player 1&apos;s Solution:</div>
            <TextInput
              value={round.p1}
              onChange={(v) => setRound((r) => ({ ...r, p1: v }))}
              placeholder="e.g., (100 + 6) * 2"
              disabled={!running && !done}
            />
          </div>

          <div style={{ marginTop: 14 }}>
            <div style={{ fontWeight: 900, marginBottom: 8 }}>Player 2&apos;s Solution:</div>
            <TextInput
              value={round.p2}
              onChange={(v) => setRound((r) => ({ ...r, p2: v }))}
              placeholder="e.g., (100 + 6) * 2"
              disabled={!running && !done}
            />
          </div>
        </>
      )}

      {done && round.results && (
        <Card style={{ marginTop: 16 }}>
          <div style={{ textAlign: "center", fontWeight: 900, fontSize: 20, opacity: 0.95 }}>Time&apos;s Up!</div>

          <NumbersResultRow
            label="Player 1"
            expr={round.results.p1.expr}
            value={round.results.p1.value}
            target={round.results.target}
            base={round.results.p1.base}
            points={round.results.p1.points}
            isWinner={round.results.winner === 1}
            usedOk={round.results.p1.usedOk}
          />
          <NumbersResultRow
            label="Player 2"
            expr={round.results.p2.expr}
            value={round.results.p2.value}
            target={round.results.target}
            base={round.results.p2.base}
            points={round.results.p2.points}
            isWinner={round.results.winner === 2}
            usedOk={round.results.p2.usedOk}
          />

          <div style={{ marginTop: 12 }}>
            <Button variant="ghost" onClick={onNext}>
              Next Round
            </Button>
          </div>
        </Card>
      )}
    </Card>
  );
}

function NumbersResultRow({ label, expr, value, target, base, points, isWinner, usedOk }) {
  const ok = value != null;
  const diff = ok ? Math.abs(target - value) : null;
  const usageText = usedOk ? "✓ Uses selected numbers" : "✗ Uses invalid/reused/unknown numbers";

  return (
    <div
      style={{
        marginTop: 12,
        borderRadius: 14,
        padding: 12,
        border: `1px solid ${isWinner ? "rgba(18,164,74,0.55)" : "rgba(255,255,255,0.14)"}`,
        background: isWinner ? "rgba(18,164,74,0.12)" : "rgba(255,255,255,0.05)",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 900 }}>
        <div>{label}</div>
        <div style={{ opacity: 0.95 }}>{expr || "-"}</div>
      </div>
      <div style={{ marginTop: 6, opacity: 0.9 }}>
        {usageText}
        {" • "}
        {ok ? `= ${Math.round(value * 1000) / 1000}` : "Invalid expression"}
        {ok ? ` • diff ${diff}` : ""}
        {ok ? ` • ${base} pts` : ""}
        {isWinner && points > 0 ? <span style={{ marginLeft: 10 }}>🏆 Winner! +{points} points</span> : null}
        {!isWinner && points > 0 ? <span style={{ marginLeft: 10 }}>+{points} points</span> : null}
      </div>
    </div>
  );
}

/** -------------------- CONUNDRUM ROUND -------------------- **/

function makeConundrumRound(wordSet, nineIndex) {
  const fallback = "INVIOLATE"; // 9 letters

  let answer = fallback;
  if (nineIndex && Array.isArray(nineIndex) && nineIndex.length > 1000) {
    answer = pickRandom(nineIndex);
  } else if (wordSet && wordSet.size > 0) {
    const nine = [];
    for (const w of wordSet) {
      if (w.length === 9) nine.push(w);
      if (nine.length >= 20000) break;
    }
    if (nine.length) answer = pickRandom(nine);
  }

  const letters = shuffle(answer.split(""));
  return {
    phase: "READY", // READY | RUNNING | DONE
    answer,
    letters,
    secondsLeft: DEFAULT_SECONDS,
    p1: "",
    p2: "",
    results: null,
  };
}

function ConundrumRound({ round, setRound, onAward, onNext, wordSet }) {
  const running = round.phase === "RUNNING";
  const done = round.phase === "DONE";

  useCountdownTimer(round, setRound);

  function startTimer() {
    setRound((r) => {
      if (r.phase !== "READY") return r;
      return { ...r, phase: "RUNNING", secondsLeft: DEFAULT_SECONDS };
    });
  }

  function finishRound() {
    const a = round.answer;
    const g1 = (round.p1 || "").trim().toUpperCase();
    const g2 = (round.p2 || "").trim().toUpperCase();

    const c1 = g1 === a;
    const c2 = g2 === a;

    const dictOk = !wordSet ? true : wordSet.has(a);
    const c1Final = c1 && dictOk;
    const c2Final = c2 && dictOk;

    const p1Add = scoreConundrum(c1Final);
    const p2Add = scoreConundrum(c2Final);

    let winner = 0;
    if (p1Add && p2Add) winner = 0;
    else if (p1Add) winner = 1;
    else if (p2Add) winner = 2;

    onAward(p1Add, p2Add, "conundrum", Math.max(p1Add, p2Add));

    setRound((r) => ({
      ...r,
      phase: "DONE",
      results: {
        answer: a,
        p1: { guess: g1, correct: c1Final, points: p1Add },
        p2: { guess: g2, correct: c2Final, points: p2Add },
        winner,
      },
    }));
  }

  useEffect(() => {
    if (round.phase === "RUNNING" && round.secondsLeft <= 0) {
      setRound((r) => ({ ...r, phase: "DONE" }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [round.secondsLeft, round.phase]);

  useEffect(() => {
    if (round.phase === "DONE" && !round.results) finishRound();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [round.phase]);

  return (
    <Card>
      <div style={{ textAlign: "center", fontSize: 40, fontWeight: 900 }}>Conundrum Round</div>

      <div style={{ textAlign: "center", marginTop: 10, opacity: 0.9 }}>
        Unscramble the letters to find the 9-letter word!
      </div>

      <div style={{ marginTop: 16, display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
        <div style={{ display: "flex", gap: 12 }}>
          {round.letters.slice(0, 4).map((ch, i) => (
            <Tile key={i} text={ch} />
          ))}
        </div>
        <div style={{ display: "flex", gap: 12 }}>
          {round.letters.slice(4, 8).map((ch, i) => (
            <Tile key={i + 4} text={ch} />
          ))}
        </div>
        <div>
          <Tile text={round.letters[8]} />
        </div>
      </div>

      <div style={{ marginTop: 18 }}>
        <Button variant="green" onClick={startTimer} disabled={round.phase !== "READY"}>
          Start Timer
        </Button>
      </div>

      {(running || done) && <TimerBar totalSeconds={DEFAULT_SECONDS} secondsLeft={round.secondsLeft} running={running} />}

      <div style={{ marginTop: 14 }}>
        <div style={{ fontWeight: 900, marginBottom: 8 }}>Player 1&apos;s Answer:</div>
        <TextInput
          value={round.p1}
          onChange={(v) => setRound((r) => ({ ...r, p1: v }))}
          placeholder="ENTER WORD..."
          disabled={!running && !done}
        />
      </div>

      <div style={{ marginTop: 14 }}>
        <div style={{ fontWeight: 900, marginBottom: 8 }}>Player 2&apos;s Answer:</div>
        <TextInput
          value={round.p2}
          onChange={(v) => setRound((r) => ({ ...r, p2: v }))}
          placeholder="ENTER WORD..."
          disabled={!running && !done}
        />
      </div>

      {done && round.results && (
        <Card style={{ marginTop: 16 }}>
          <div style={{ textAlign: "center", fontWeight: 900, fontSize: 20 }}>Time&apos;s Up!</div>

          <div style={{ marginTop: 10, textAlign: "center", opacity: 0.95 }}>
            Correct answer: <b>{round.results.answer}</b>
          </div>

          <ConResultRow label="Player 1" res={round.results.p1} isWinner={round.results.winner === 1} />
          <ConResultRow label="Player 2" res={round.results.p2} isWinner={round.results.winner === 2} />

          <div style={{ marginTop: 12 }}>
            <Button variant="ghost" onClick={onNext}>
              Next Round
            </Button>
          </div>
        </Card>
      )}
    </Card>
  );
}

function ConResultRow({ label, res, isWinner }) {
  return (
    <div
      style={{
        marginTop: 12,
        borderRadius: 14,
        padding: 12,
        border: `1px solid ${isWinner ? "rgba(18,164,74,0.55)" : "rgba(255,255,255,0.14)"}`,
        background: isWinner ? "rgba(18,164,74,0.12)" : "rgba(255,255,255,0.05)",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 900 }}>
        <div>{label}</div>
        <div>{res.guess || "-"}</div>
      </div>
      <div style={{ marginTop: 6, opacity: 0.9 }}>
        {res.correct ? "✓ Correct" : "✗ Incorrect"}
        {isWinner && res.points > 0 ? <span style={{ marginLeft: 10 }}>🏆 Winner! +{res.points} points</span> : null}
        {!isWinner && res.points > 0 ? <span style={{ marginLeft: 10 }}>+{res.points} points</span> : null}
      </div>
    </div>
  );
}

/** -------------------- TIMER HOOK -------------------- **/

function useCountdownTimer(round, setRound) {
  const intervalRef = useRef(null);

  useEffect(() => {
    const running = round?.phase === "RUNNING";
    if (!running) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      intervalRef.current = null;
      return;
    }

    if (!intervalRef.current) {
      intervalRef.current = setInterval(() => {
        setRound((r) => {
          if (!r || r.phase !== "RUNNING") return r;
          const next = r.secondsLeft - 1;
          return { ...r, secondsLeft: Math.max(0, next) };
        });
      }, 1000);
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      intervalRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [round?.phase]);
}

/** -------------------- FREEPLAY -------------------- **/

function makeNewFreeplayState() {
  return {
    total: 0,
    letters: 0,
    numbers: 0,
    conundrum: 0,
    mode: "MENU", // MENU | LETTERS | NUMBERS | CONUNDRUM
    round: null,
  };
}

function Freeplay({ state, setState, onBackToMode, wordSet, nineIndex }) {
  function start(type) {
    setState((s) => ({
      ...s,
      mode: type,
      round: makeRoundState(type, wordSet, nineIndex),
    }));
  }

  function award(points, bucket) {
    setState((s) => ({
      ...s,
      total: s.total + points,
      [bucket]: s[bucket] + points,
    }));
  }

  function backToMenu() {
    setState((s) => ({ ...s, mode: "MENU", round: null }));
  }

  return (
    <div style={{ maxWidth: 520, margin: "0 auto", display: "flex", flexDirection: "column", gap: 14 }}>
      <SmallButton onClick={onBackToMode} style={{ width: "100%" }}>
        ← Back to Mode Selection
      </SmallButton>

      <Card style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ fontSize: 28 }}>🏆</div>
          <div>
            <div style={{ fontSize: 22, fontWeight: 900 }}>Total Score: {state.total}</div>
            <div style={{ opacity: 0.9, marginTop: 4 }}>
              Letters: {state.letters} &nbsp;&nbsp; Numbers: {state.numbers} &nbsp;&nbsp; Conundrum: {state.conundrum}
            </div>
          </div>
        </div>
      </Card>

      {state.mode === "MENU" && (
        <Card>
          <div style={{ textAlign: "center", fontSize: 34, fontWeight: 900 }}>Free Mode</div>
          <div style={{ textAlign: "center", marginTop: 10, opacity: 0.9 }}>Choose a round type</div>

          <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 16 }}>
            <Button variant="ghost" onClick={() => start("LETTERS")}>
              Letters Round
            </Button>
            <Button variant="ghost" onClick={() => start("NUMBERS")}>
              Numbers Round
            </Button>
            <Button variant="ghost" onClick={() => start("CONUNDRUM")}>
              Conundrum Round
            </Button>
            <Button variant="ghost" onClick={onBackToMode}>
              ← Back to Menu
            </Button>
          </div>
        </Card>
      )}

      {state.mode !== "MENU" && (
        <>
          <SmallButton onClick={backToMenu} style={{ width: "100%" }}>
            ← Back to Menu
          </SmallButton>

          {state.mode === "LETTERS" && (
            <LettersRound
              round={state.round}
              setRound={(u) => setState((s) => ({ ...s, round: typeof u === "function" ? u(s.round) : u }))}
              onAward={(p1Add) => award(p1Add, "letters")}
              onNext={() => start("LETTERS")}
              wordSet={wordSet}
            />
          )}

          {state.mode === "NUMBERS" && (
            <NumbersRound
              round={state.round}
              setRound={(u) => setState((s) => ({ ...s, round: typeof u === "function" ? u(s.round) : u }))}
              onAward={(p1Add) => award(p1Add, "numbers")}
              onNext={() => start("NUMBERS")}
            />
          )}

          {state.mode === "CONUNDRUM" && (
            <ConundrumRound
              round={state.round}
              setRound={(u) => setState((s) => ({ ...s, round: typeof u === "function" ? u(s.round) : u }))}
              onAward={(p1Add) => award(p1Add, "conundrum")}
              onNext={() => start("CONUNDRUM")}
              wordSet={wordSet}
              nineIndex={nineIndex}
            />
          )}
        </>
      )}
    </div>
  );
}


/** -------------------- ONLINE UI -------------------- **/

function OnlineMenu({ name, onNameChange, status, error, onCreate, onJoin, onBack }) {
  const [code, setCode] = React.useState("");
  return (
    <div>
      <button style={styles.backButton} onClick={onBack}>← Back</button>

      <Card>
        <div style={{ fontSize: 34, fontWeight: 900, textAlign: "center" }}>Play Online</div>
        <div style={{ opacity: 0.9, textAlign: "center", marginTop: 10 }}>
          Create a room code to play with friends on other devices.
        </div>

        <div style={{ marginTop: 16 }}>
          <div style={{ fontWeight: 900, marginBottom: 6 }}>Your Name</div>
          <input
            style={styles.input}
            value={name}
            onChange={(e) => onNameChange(e.target.value)}
            placeholder="Enter name..."
          />
        </div>

        {error && (
          <div style={{ marginTop: 12, padding: 12, borderRadius: 10, background: "rgba(255,0,0,0.15)" }}>
            <div style={{ fontWeight: 900 }}>Error</div>
            <div style={{ marginTop: 6, wordBreak: "break-word" }}>{error}</div>
          </div>
        )}

        <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
          <button style={styles.greenButton} onClick={onCreate} disabled={status === "creating" || status === "joining"}>
            {status === "creating" ? "Creating..." : "Create Room"}
          </button>
          <div style={{ flex: 1 }} />
        </div>

        <div style={{ marginTop: 18 }}>
          <div style={{ fontWeight: 900, marginBottom: 6 }}>Join Room</div>
          <input
            style={styles.input}
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="Enter room code..."
          />
          <button
            style={{ ...styles.blueButton, marginTop: 10, width: "100%" }}
            onClick={() => onJoin(code)}
            disabled={status === "creating" || status === "joining"}
          >
            {status === "joining" ? "Joining..." : "Join"}
          </button>
        </div>
      </Card>
    </div>
  );
}

function OnlineLobby({ online, onBack }) {
  const room = online.room;
  const players = room?.players ? Object.entries(room.players).map(([id, p]) => ({ id, ...p })) : [];
  return (
    <div>
      <button style={styles.backButton} onClick={onBack}>← Back</button>

      <Card>
        <div style={{ fontSize: 34, fontWeight: 900, textAlign: "center" }}>Online Lobby</div>
        <div style={{ opacity: 0.9, textAlign: "center", marginTop: 10 }}>
          Share this room code with your friends:
        </div>

        <div style={{ marginTop: 14, textAlign: "center", fontSize: 42, fontWeight: 900, letterSpacing: 4 }}>
          {online.code || "—"}
        </div>

        {!room && (
          <div style={{ marginTop: 14, textAlign: "center", opacity: 0.9 }}>Connecting…</div>
        )}

        {online.error && (
          <div style={{ marginTop: 12, padding: 12, borderRadius: 10, background: "rgba(255,0,0,0.15)" }}>
            <div style={{ fontWeight: 900 }}>Error</div>
            <div style={{ marginTop: 6, wordBreak: "break-word" }}>{online.error}</div>
          </div>
        )}

        <div style={{ marginTop: 18 }}>
          <div style={{ fontWeight: 900, marginBottom: 8 }}>Players</div>
          {players.length === 0 ? (
            <div style={{ opacity: 0.9 }}>No players yet.</div>
          ) : (
            <div style={{ display: "grid", gap: 8 }}>
              {players.map((p) => (
                <div key={p.id} style={{ padding: 10, borderRadius: 10, background: "rgba(255,255,255,0.10)" }}>
                  <div style={{ fontWeight: 900 }}>{p.name || "Player"}</div>
                  <div style={{ opacity: 0.85, marginTop: 2 }}>Score: {p.score || 0}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div style={{ marginTop: 18, opacity: 0.9 }}>
          Online gameplay sync is enabled (rooms & players). Next step is syncing rounds/timers/answers.
        </div>
      </Card>
    </div>
  );
}
